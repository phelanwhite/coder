const ENV = {
  PORT_SERVER: `http://localhost:5000/api/v1/`,
  // PORT_SERVER: `/api/v1/`,
};
export default ENV;
