import express from "express";

const adminRouter = express();

export default adminRouter;
